#include "interface.h"

int main() {
    begin();
    return 0;
}
